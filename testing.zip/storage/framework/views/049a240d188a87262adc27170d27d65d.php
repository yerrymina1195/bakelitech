<?php
use App\View\Components\Button2;
?>

<div>
    <a href="#"
    class="bg-gray-900 inline-flex items-center px-3 py-2 text-sm font-medium text-center text-white hover:bg-gray-600 focus:ring-4 focus:outline-none focus:ring-gray-900">
         LEARN MORE
    </a>
</div><?php /**PATH C:\Users\Diakho\Documents\tachelaravel\testing\resources\views/components/button2.blade.php ENDPATH**/ ?>