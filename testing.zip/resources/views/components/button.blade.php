<?php
use App\View\Components\Button;
?>


    <button type="button"
        class="py-2.5 px-5 mr-2 h-10 mb-2 text-sm font-medium text-white focus:outline-none bg-greenbakeli border-orange-500 border-r-4 hover:bg-green-700 hover:text-white-700 focus:z-10 focus:ring-4 focus:ring-gray-200 ">
        {{ $attributes['title'] }} 
    </button>